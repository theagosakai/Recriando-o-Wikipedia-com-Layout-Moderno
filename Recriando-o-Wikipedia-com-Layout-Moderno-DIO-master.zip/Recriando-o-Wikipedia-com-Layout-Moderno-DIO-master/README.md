# Desafio 03 - Recriando o Wikipedia com Layout Moderno





## Objetivo
O desafio consiste em criar a estrutura do site, aplicando todos os conhecimentos para criar um codigo semântico e com acessibilidade.




## Referencias
- [Wikipedia](https://pt.wikipedia.org/wiki/Severance_(s%C3%A9rie_de_televis%C3%A3o)) Severance

- [Youtube](https://www.youtube.com/watch?v=EFjc_qHrnsQ) Ruptura — Trailer oficial - Dublado | Apple TV+ 

- [Youtube](https://www.youtube.com/watch?v=xEQP4VVuyrY) Severance — Official Trailer | Apple TV+

- [Apple TV+](https://tv.apple.com/)




![GIF de um teclado usado na serie Ruptura](/imagens/keyboard.gif)